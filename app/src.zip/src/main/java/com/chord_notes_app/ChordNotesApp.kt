package com.chord_notes_app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ChordNotesApp: Application() {


}