package com.chord_notes_app.models

interface User {
    val id: Int
    val username: String
    val email: String
    val first_name: String
    val last_name: String

}