package com.chord_notes_app.di

import com.chord_notes_app.api.AuthApi
import com.chord_notes_app.api.GroupsApi
import com.chord_notes_app.api.SongsApi
import com.chord_notes_app.utils.constants.BASE_URL
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideRetrofit() : Retrofit {
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    @Provides
    @Singleton
    fun provideAuthApi(retrofit: Retrofit) : AuthApi {
        return retrofit.create(AuthApi::class.java)
    }

    @Provides
    @Singleton
    fun provideSongsApi(retrofit: Retrofit) : SongsApi {
        return retrofit.create(SongsApi::class.java)
    }

    @Provides
    @Singleton
    fun provideGroupsApi(retrofit: Retrofit) : GroupsApi {
        return retrofit.create(GroupsApi::class.java)
    }





}