package com.chord_notes_app.data

data class Member(
    val email: String,
    val id: Int,
    val username: String,
    val id_member: Int
)