package com.chord_notes_app.data

data class NameResponse(
    val id: Int,
    val name: String
)
