package com.chord_notes_app.data

import androidx.compose.runtime.MutableState

data class Lyrics(
    val lines: Map<Int, String>
)