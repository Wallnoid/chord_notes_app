package com.chord_notes_app.data

data class MemberResponse(

    val id: Int,
    val user: Int,
    val group: Int,
    val role: String
)
