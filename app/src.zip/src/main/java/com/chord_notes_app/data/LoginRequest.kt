package com.chord_notes_app.data

data class LoginRequest(
    val username: String,
    val password: String
)
