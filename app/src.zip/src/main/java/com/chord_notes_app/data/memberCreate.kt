package com.chord_notes_app.data


data class MemberCreate(
    val user: Int,
    val grupo: Int,
    val role: String
)