package com.chord_notes_app.data

data class Role(
    val grupo: Int,
    val role: String,
    val user: Int
)