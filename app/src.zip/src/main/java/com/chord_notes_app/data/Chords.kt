package com.chord_notes_app.data

data class Chords(
    val lines: MutableMap<Int, MutableList<String>>
)