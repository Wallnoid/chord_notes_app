package com.chord_notes_app.data

data class RegisterRequest(
    val username: String,
    val password: String,
    val email: String
)
