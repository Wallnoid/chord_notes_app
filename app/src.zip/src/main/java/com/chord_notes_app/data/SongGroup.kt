package com.chord_notes_app.data

data class SongGroup(
    val song: Int,
    val grupo: Int
)
